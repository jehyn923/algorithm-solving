package com.java.first;

import java.util.Scanner;

public class Compute {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
	
		int multiplication = num1*num2;
		int division = (num1>num2) ? num1/num2 : num2/num1; 
		
		System.out.println("곱="+multiplication);
		System.out.println("몫="+division);
	}
}
