package com.java.first;

import java.util.Scanner;

public class CheckPoint {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int height = sc.nextInt();
		int weight = sc.nextInt();
		
		int result = -height + weight + 100;
		boolean overweight = false;
		
		if(result>0) {
			overweight=true;
		}
		System.out.println("비만수치는 "+result+"입니다.");
		
		if(overweight) {
			System.out.println("당신은 비만이군요");
		}
	}
}
