package com.ssafy.algo.hw0819;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

public class BOJ_1987 {	
	static int cnt;
	static int R;
	static int C;
	static int finalCnt = -1;
	static Set<Character> route;
	static char[][] map;
	static int[][] directions = {{-1,0},{0,1},{1,0},{0,-1}};
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine()," ");
		R = Integer.parseInt(st.nextToken());
		C = Integer.parseInt(st.nextToken());
		map = new char[R][];
		route = new HashSet<Character>();
		for(int i = 0 ; i < R ; i++) {
			map[i] = br.readLine().toCharArray();
		}
		cnt=1;
		move(0,0);
		
		System.out.println(finalCnt);
	}
	private static void move(int y, int x) {
		
		route.add(map[y][x]);
		if(finalCnt<cnt) {
			finalCnt = cnt;
		}
		for(int i = 0 ; i < directions.length ; i ++) {
			int dy = y + directions[i][0];
			int dx = x + directions[i][1];
			if(isAvailable(dy,dx)) {
				cnt++;
				move(dy,dx);
				route.remove(map[dy][dx]);
				cnt --; 
			}
		}
		
	}
	private static boolean isAvailable(int y, int x) {
		if( y>=0 && y<R  && x>=0 && x<C &&!route.contains(map[y][x])) {
			return true;
		}
		return false;
	}
	
	

}
