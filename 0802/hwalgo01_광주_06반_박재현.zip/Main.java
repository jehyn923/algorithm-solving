package com.ssafy.algo.hw0802;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Main {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int num = Integer.parseInt(br.readLine());
		int[] light = new int[num];
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		StringBuilder sb = new StringBuilder();
		//light 초기화
		for(int i=0; i < num;i++) {
			light[i] = Integer.parseInt(st.nextToken());
		}
		
		int caseCnt = Integer.parseInt(br.readLine());
		//case대로 돌려보기
		for(int i = 0 ; i<caseCnt;i++) {
			st = new StringTokenizer(br.readLine()," ");
			switch(Integer.parseInt(st.nextToken())) {
			case 1:
				maleSwitch(light, Integer.parseInt(st.nextToken()));
				break;
			case 2:
				int position = Integer.parseInt(st.nextToken());
				position = position-1;
				light[position] = light[position]^1;
				femaleSwitch(light, position-1, position+1);
				break;
			}
		}
		int i = 0 ;
		while(i<light.length) {
			sb.append(light[i]);
			sb.append(" ");
			if((i+1)%20==0) {
				sb.append("\n");
			}
			i++;
		}
		
		System.out.println(sb.toString());
		
	}	
	static int cnt = 1;

	public static void maleSwitch(int[] light, int num) {
		if(num>light.length) {
			cnt = 1; 
			return;
		}
		else {
			light[num-1] = light[num-1]^1;
			maleSwitch(light,num/cnt*++cnt);
			return;
		}
	}
	public static void femaleSwitch(int[] light, int first, int second) {
		if(first>=0&&second<light.length) {
			if(light[first]==light[second]) {

				light[first] = light[first]^1;
				light[second] = light[second]^1;
				femaleSwitch(light, first-1, second+1);
			}
			return;
		}else {
			return;
		
		}
	}
}
