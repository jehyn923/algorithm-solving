package com.ssafy.algo.hw0812;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class B3040 {
	static int[] heights = new int[9];
	static int N = 7;
	static int sCount = 0;
	private static void makeCombination(int toSelect, int[] selected,int startIdx) {
		int sum = 0;
		if(toSelect==N) {
			for(int i = 0 ; i <  7; i ++) {
				sum+=selected[i];
			}
			
			if(sum==100) {
				Arrays.sort(selected);
				for(int i = 0 ; i<7;i++) {
					System.out.println(selected[i]);
				}
			}
			
			return;
		}
		for(int i =  startIdx; i<heights.length; i++) {
			selected[toSelect]=heights[i];
			makeCombination(toSelect+1, selected, i+1);
		}
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		for (int i = 0; i < 9; i++) {
			heights[i] =Integer.parseInt(br.readLine());
		}
		 makeCombination(0, new int[N],0); 
		
	}
}
