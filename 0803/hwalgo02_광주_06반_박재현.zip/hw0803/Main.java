package com.ssafy.algo.hw0803;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringBuilder sb = new StringBuilder();

		int tc = Integer.parseInt(br.readLine());
		for (int TC = 0; TC < tc; TC++) {

			sb.append("#" + (TC+1) + "\n");
			int num = Integer.parseInt(br.readLine());
			int[][] print = new int[num][num];

			int[][] direction = { { 0, 1 }, { 1, 0 }, { 0, -1 }, { -1, 0 } };

			int row = 0;
			int col = 0;

			int i = 1;
			int lastInt = num * num;
			print[0][0] = 1;
			while (i < lastInt) {
				for (int j = 0; j < direction.length; j++) {
					int nr = row + direction[j][0];
					int nc = col + direction[j][1];

					while (nc >= 0 && nc < num && nr >= 0 && nr < num && print[nr][nc] == 0) {
						print[nr][nc] = ++i;
						row = nr;
						col = nc;
						nr = nr + direction[j][0];
						nc = nc + direction[j][1];
					}
				}
			}
			for (int k = 0; k < num; k++) {
				for (int j = 0; j < num; j++) {
					sb.append(print[k][j]+" ");
				}
				sb.append("\n");
			}
		}
		System.out.println(sb.toString());

	}
}
