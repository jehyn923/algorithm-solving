package com.java.seventh;

public class Refrigerator extends Product {

	private double capacity;
	
	public Refrigerator() {
		super();
		System.out.println("** Refrigerator **");
	}

	public Refrigerator(int number, String name, int price, int quantity, double capacity) {
		super(number,name,price,quantity);
		this.capacity = capacity;
		
	}
	public double getCapacity() {
		return capacity;
	}

	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return super.toString()
				+ "\t|용량 : " + this.capacity;
	}
	
	
}
