package com.java.seventh;

import java.util.ArrayList;

public interface IProductMgr {
	void add(Product product);
	void remove(int number);
	ArrayList<Product> getProductList();
	Product getProductByNumber(int num);
	ArrayList<Product> getProductByName(String name);
	ArrayList<TV> getTV();
	ArrayList<Refrigerator> getRefrigerator();
	ArrayList<Refrigerator> getBigRefrigerator();
	ArrayList<TV> getBigTV();
	void changePrice(int num, int price);
	int getTotalPrice();
}
