package com.java.seventh;

import java.util.ArrayList;

public class ProductMgrImpl implements IProductMgr {
	static int MAX_SIZE = 100;
	ArrayList<Product> productStock = new ArrayList();
	int size;
	@Override
	public void add(Product product) {
		productStock.add(product);
		size++;
	}
	public void remove(int number) {
		for(int i=0;i<size;i++) {
			if(productStock.get(i).getNumber() == number) {
				productStock.remove(i);
			}
		}
	}
	@Override
	public ArrayList<Product> getProductList() {
		return productStock;
	}
	public Product getProductByNumber(int number) {
		for(int i = 0 ; i < size ; i ++) {
			if(productStock.get(i).getNumber()==number) {
				return productStock.get(i);
			}
		}
		return null;
	}
	@Override
	public ArrayList<Product> getProductByName(String name) { // 부분 검색 가능
		ArrayList<Product> result = new ArrayList();
		for(int i = 0 ; i < size; i++) {
			if(productStock.get(i).getName().contains(name)) {
				result.add(productStock.get(i));
			}
		}
		return result;
	}
	@Override
	public ArrayList<TV> getTV() {
		ArrayList<TV> result = new ArrayList();
		
		for(int i =0 ; i <size;i++) {
			if(productStock.get(i) instanceof TV) {
				result.add((TV)productStock.get(i));
			}
		}
		
		return result;
	}
	@Override
	public ArrayList<Refrigerator> getRefrigerator() {
		ArrayList<Refrigerator> result = new ArrayList();
		for(int i = 0 ; i < size ; i ++) {
			if(productStock.get(i) instanceof Refrigerator) {
				result.add((Refrigerator)productStock.get(i));
			}
		}
		
		return result;
	}
	@Override
	public int getTotalPrice() {
		int sum = 0;
		for(Product product: productStock) {
			if(product!=null) {
				sum+= product.getPrice();
			}
		}
		return sum;
	}
	@Override
	public ArrayList<Refrigerator> getBigRefrigerator() {
		ArrayList<Refrigerator> result = new ArrayList();
		
		for(int i = 0 ; i < size ; i++) {
			if(productStock.get(i) instanceof Refrigerator) {
				Refrigerator tmp = (Refrigerator)productStock.get(i);
				if(tmp.getCapacity()>=400) {
					result.add(tmp);
				}
			}
		}
		return result;
	}
	@Override
	public ArrayList<TV> getBigTV() {
		ArrayList<TV> result = new ArrayList();
		
		for(int i = 0 ; i < size ; i++) {
			if(productStock.get(i) instanceof TV) {
				TV tmp = (TV)productStock.get(i);
				if(tmp.getSize()>=50) {
					result.add(tmp);
				}
			}
		}
		return result;
	}
	@Override
	public void changePrice(int num, int price) {
		this.getProductByNumber(num).setPrice(price);
	}
	
}
