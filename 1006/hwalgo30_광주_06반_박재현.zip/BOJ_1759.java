package com.ssafy.algo.hw0823;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BOJ_1759 {

	static int L;
	static int C; 
	static int vowels;
	static int consonants;
	static char[] word;
	static char[] numbers;
	static StringBuilder sb = new StringBuilder();
	static boolean[] isSelected;
	private static void combination(int cnt,int start) {
		if(cnt == L) {
			if(vowels<1) return;
			if(consonants<2) return;
			for(int i = 0; i < L ; i ++) {
				sb.append(numbers[i]);
			}
			sb.append('\n');
			return;
		}
		// 가능한 모든 수 시도
		for (int i = start; i < C; i++) {

			if(word[i]!='a'&&word[i]!='e'&&word[i]!='i'&&word[i]!='o'&&word[i]!='u') {
				consonants++;
			}
			else {
				vowels++;
			}
			
			numbers[cnt] = word[i];
			combination(cnt+1,i+1);
			
		
			if(word[i]!='a'&&word[i]!='e'&&word[i]!='i'&&word[i]!='o'&&word[i]!='u') {
				consonants--;
			}
			else {
				vowels--;
			}
			
		}
		
	}
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		StringTokenizer st = new StringTokenizer(br.readLine()," ");
		L = Integer.parseInt(st.nextToken());
		C = Integer.parseInt(st.nextToken());

		char[] temp = br.readLine().toCharArray();
		numbers = new char[L];
		word = new char[C];
		isSelected = new boolean[C];
		int cnt =0;
		for(int i = 0 ; i < temp.length ; i++) {
			if(temp[i]>='a'&&temp[i]<='z'||temp[i]>='A'&&temp[i]<='Z')
			word[cnt++] = temp[i];
		}
		Arrays.sort(word);
		combination(0,0);
		System.out.println(sb.toString());
	}
}
