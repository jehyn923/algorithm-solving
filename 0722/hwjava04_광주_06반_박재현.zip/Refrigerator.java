package com.java.fourth;

public class Refrigerator {
	private int number;
	private String name;
	private int price;
	private int quantity;
	private double capacity;
	
	public Refrigerator() {
		super();
		System.out.println("** Refrigerator **");
	}

	public Refrigerator(int number, String name, int price, int quantity, double capacity) {
		this();
		this.number = number;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.capacity = capacity;
		
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getCapacity() {
		return capacity;
	}

	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return "제품번호: " + this.number
				+ "\n제품이름 : " + this.name
				+ "\n가격 : " + this.price
				+ "\n수량 : " + this.quantity
				+ "\n용량 : " + this.capacity;
	}
	
	
}
