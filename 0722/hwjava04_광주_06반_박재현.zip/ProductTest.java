package com.java.fourth;

public class ProductTest {
	public static void main(String[] args) {
			TV tv = new TV(100,"TV", 500000, 100, 55, 'A');
			System.out.println(tv);
			
			Refrigerator ref = new Refrigerator(201,"냉장고",1000000, 200, 500);
			System.out.println(ref);
	}
}
