package com.java.fourth;

public class TV {
	private int number;
	private String name;
	private int price;
	private int quantity;
	private double size;
	private char type;
	
	public TV() {
		super();
		System.out.println("** TV **");
	}
	public TV(int number, String name, int price, int quantity, double size, char type) {
		this();
		this.number = number;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.size = size;
		this.type = type;
		
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	public char getType() {
		return type;
	}
	public void setType(char type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "제품번호: " + this.number
				+ "\n제품이름 : " + this.name
				+ "\n가격 : " + this.price
				+ "\n수량 : " + this.quantity
				+ "\n인치 : " + this.size
				+ "\n디스플레이 타입 : " + this.type;
	}
	
	
	
}
