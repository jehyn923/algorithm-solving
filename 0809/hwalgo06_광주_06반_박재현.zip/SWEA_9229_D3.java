package com.ssafy.algo.hw0809;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class SWEA_9229_D3 {
	static int[] snack;
	static int Max = 2;
	static int M;
	static int MaxWeight=-1;
	private static void makeCombination(int toSelect, int[] selected, int startIdx) {
		if (toSelect == Max) {
			int sum = 0;
			for(int j= 0;j < toSelect;j++) {
				sum += selected[j];
			}
			if(sum<=M) {
				if(sum>MaxWeight) {
					MaxWeight = sum;
				}
			}
			return;
		}
		for (int i = startIdx; i < snack.length; i++) {
			selected[toSelect] = snack[i];
			makeCombination(toSelect + 1, selected, i + 1);
		}
	}
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TC = Integer.parseInt(br.readLine());
		int N;
		StringTokenizer st;
		StringBuilder sb = new StringBuilder();
		for (int tc = 0; tc < TC; tc++) {
			st = new StringTokenizer(br.readLine(), " ");
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			snack = new int[N];
			st = new StringTokenizer(br.readLine(), " ");

			for(int i = 0 ; i < N ;i++) {
				snack[i] = Integer.parseInt(st.nextToken());
			}
			makeCombination(0, new int[N], 0);
			sb.append("#"+(tc+1)+" "+MaxWeight+"\n");
			MaxWeight = -1 ;
		}
		System.out.println(sb);
	}
}
