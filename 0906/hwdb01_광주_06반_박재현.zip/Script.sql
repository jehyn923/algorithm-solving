create database hwdb;

use hwdb;

-- 상품 정보를 저장할 수 있는 테이블을 구성하여 보자.
CREATE TABLE products
(pcode int(4) not null auto_increment PRIMARY KEY,
pname VARCHAR(100) not null,
price int(100) not null);

# 상품 데이터를 5개 이상 저장하는 SQL을 작성하여 보자.
insert into products(pname,price)
values 
('TV', 50000000),
('COMPUTER', 5000000),
('REFRIGERATOR', 10000000),
('SMARTPHONE', 120000),
('MOUSE', 50000),
('LAPTOP', 1000000),
('SPEAKER', 220000);

# 상품을 세일하려고 한다. 15% 인하된 가격의 상품 정보를 출력하세요.
SELECT pname, (price*0.85) from products;

# TV 관련 상품을 가격을 20% 인하하여 저장하세요. 그리고 그 결과를 출력하세요.
UPDATE products 
set price = price * 0.8
where pname LIKE '%TV%';

select price from products 
where pname like '%TV%';

select sum(price) from products;
