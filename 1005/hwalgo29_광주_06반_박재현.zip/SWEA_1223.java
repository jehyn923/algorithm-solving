package com.ssafy.algo.hw0820;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;

public class SWEA_1223 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		for(int tc = 0 ; tc<10; tc++) {
			int num = Integer.parseInt(br.readLine());
			StringBuilder sb = new StringBuilder();
			char[] str;
			Stack<Integer> stack = new Stack<>();
			str = br.readLine().toCharArray();

			int mul=1;
			
			for(int i = 0 ; i <num ;i++) {
				if(str[i]!='+'&&str[i]!='*') {
					stack.add(mul*(str[i]-'0'));
				}
				if(str[i]=='+') {
					mul=1;
					continue;
				}
				if(str[i]=='*') {
					if(mul!=1) {
						mul = stack.pop();
						continue;
					}
					mul*=stack.pop();
				}
				
			}
			
			int sum =0;
			while(!stack.isEmpty()) {
				sum+= stack.pop();
			}
			System.out.println("#"+(tc+1)+" "+sum);
		}

	}	

}
