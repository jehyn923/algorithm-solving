package com.ssafy.news;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class NewsDAODOMImpl implements INewsDAO {
	List<News> list = new ArrayList<>();

	@Override
	public List<News> getNewsList(String url) {
		list.removeAll(list);
		connectNews(url);
		return list;
	}

	@Override
	public News search(int index) {

		return null;
	}

	private List<News> connectNews(String url) {
		DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder parser = f.newDocumentBuilder();
			Document dom = parser.parse(new URL(url).openConnection().getInputStream());
			Element root = dom.getDocumentElement();

			NodeList n = root.getElementsByTagName("item");

			for (int i = 0; i < n.getLength(); i++) {
				NodeList child = n.item(i).getChildNodes();
				News news = new News();
				for(int j = 0 ; j < child.getLength();j++) {
					Node newsInfo = child.item(j);
					if (newsInfo.getNodeName().equals("title")) {
						news.setTitle(newsInfo.getFirstChild().getNodeValue());
					} else if (newsInfo.getNodeName().equals("link")) {
						news.setLink(newsInfo.getFirstChild().getNodeValue());
					} else if (newsInfo.getNodeName().equals("description")) {
						news.setDesc(newsInfo.getFirstChild().getNodeValue());
					}	
				}
				System.out.println(news);
				list.add(news);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;

	}
}
