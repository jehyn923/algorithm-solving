package com.ssafy.algo.w0812;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class B2961 {
	static int[][] flavor;
	static int min = 1000000000;
	static int N;
	static int R = 3;
	static int sCount = 0;

	private static void powerSet(int cnt, boolean[] isSelected) {
		if (cnt == N) {
			int sour = 1;
			int bitter = 0 ;
			sCount++;
			for (int i = 0; i < N; i++) {
				if (isSelected[i]) {
					sour *= flavor[i][0];
					bitter += flavor[i][1];
				}
			}
			if(sour ==1 && bitter ==0) {
				return;
			}
			int food = Math.abs(sour-bitter);
			if(food<min) {
				min = food;
			}
			return;
		}
		isSelected[cnt] = true;
		powerSet(cnt + 1, isSelected);
		// 비선택
		isSelected[cnt] = false;
		powerSet(cnt + 1, isSelected);

	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine());
		StringTokenizer st;
		StringBuilder sb = new StringBuilder();
		flavor = new int[N][2];
		for(int i = 0 ; i < N ; i ++) {
			st = new StringTokenizer(br.readLine()," ");
			
			flavor[i][0] = Integer.parseInt(st.nextToken());
			flavor[i][1] = Integer.parseInt(st.nextToken());
			
		}
		powerSet(0, new boolean[N]);
		System.out.println(min);
		
	}
}
