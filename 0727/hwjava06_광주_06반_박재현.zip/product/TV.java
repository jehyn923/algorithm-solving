package com.java.product;

public class TV extends Product {
	private double size;
	private char type;
	
	public TV() {
		super();
		System.out.println("** TV **");
	}
	public TV(int number, String name, int price, int quantity, double size, char type) {
		super(number,name,price,quantity);
		this.size = size;
		this.type = type;
		
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	public char getType() {
		return type;
	}
	public void setType(char type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return super.toString()
				+ "\t|인치 : " + this.size
				+ "\t|디스플레이 타입 : " + this.type;
	}
	
	
	
}
