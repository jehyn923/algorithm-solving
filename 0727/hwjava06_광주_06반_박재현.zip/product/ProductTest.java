package com.java.product;

public class ProductTest {
	public static void main(String[] args) {

		ProductMgr stock = new ProductMgr();
		stock.add(new TV(100, "TV", 500000, 100, 55, 'A'));
		stock.add(new Refrigerator(201, "냉장고", 1000000, 200, 500));

		System.out.println("*****전체 리스트*****");
		for (Product product : stock.getProductList()) {
			if (product != null) {
				System.out.println(product.toString());
			}

		}
		System.out.println("*****번호로찾기*****");
		System.out.println(stock.getProductByNumber(100));
		System.out.println("*****검색어:냉*****");

		for(Product product:stock.getProductByName("냉")) {
			System.out.println(product);
		}
		
		System.out.println("*****TV만찾기*****");
		for (TV tv : stock.getTV()) {
			if (tv != null) {
				System.out.println(tv);
			}
		}

		System.out.println("*****냉장고만찾기*****");
		for (Refrigerator refrigerator : stock.getRefrigerator()) {
			if (refrigerator != null) {
				System.out.println(refrigerator);
			}
		}

		System.out.println("*****전체 가격*****");
		System.out.println(stock.getTotalPrice());
	}
}
