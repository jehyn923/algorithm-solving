package com.java.product;

public class ProductMgr extends Product {
	static int MAX_SIZE = 100;
	Product [] productStock = new Product[MAX_SIZE];
	int size;
	
	public void add(Product product) {
		productStock[size++] = product;
	}
	public void remove(int number) {
		for(int i=0;i<size;i++) {
			if(productStock[i].getNumber() == number) {
				for(int j=i;j<size;j++) {
					try {
						productStock[j] = productStock[j+1];
					} catch(ArrayIndexOutOfBoundsException e) {
						productStock[j] = null;
					}
				}
			}
		}
	}
	public Product[] getProductList() {
		return productStock;
	}
	public Product getProductByNumber(int number) {
		for(int i = 0 ; i < size ; i ++) {
			if(productStock[i].getNumber()==number) {
				return productStock[i];
			}
		}
		return null;
	}
	public Product[] getProductByName(String name) { // 부분 검색 가능
		int cnt = 0;
		for(int i = 0 ; i < size; i++) {
			if(productStock[i].getName().contains(name)) {
				cnt ++;
			}
		}
		Product[] result = new Product[cnt];
		int idx = 0;
		for(int i = 0 ; i < size; i++) {
			if(productStock[i].getName().contains(name)) {
				result[idx++]=productStock[i];
			}
		}
		return result;
	}
	public TV[] getTV() {
		int cnt = 0;
		for(int i =0 ; i <size;i++) {
			if(productStock[i] instanceof TV) {
				cnt ++;
			}
		}
		TV[] result = new TV[cnt];
		int idx = 0;
		for(int i = 0 ; i < size;i++) {
			if(productStock[i] instanceof TV) {
				result[idx++] = (TV)productStock[i];
			}
		}
		
		return result;
	}
	public Refrigerator[] getRefrigerator() {
		int cnt = 0;
		for(int i = 0 ; i < size ; i ++) {
			if(productStock[i] instanceof Refrigerator) {
				cnt++;
			}
		}
		Refrigerator[] result = new Refrigerator[cnt];
		int idx =0;
		for(int i = 0 ; i < size;i++) {
			if(productStock[i] instanceof Refrigerator) {
				result[idx++] = (Refrigerator)productStock[i];
			}
		}
		
		return result;
	}
	public int getTotalPrice() {
		int sum = 0;
		for(Product product: productStock) {
			if(product!=null) {
				sum+= product.getPrice();

			}
		}
		return sum;
	}
	
	
	
}
