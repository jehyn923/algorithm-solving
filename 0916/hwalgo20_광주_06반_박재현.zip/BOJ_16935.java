package com.ssafy.algo.hw0811;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.StringTokenizer;

public class BOJ_16935 {
	static int[][] arry;
	static int N;
	static int M;
	static int R;
	static LinkedList<LinkedList<Integer>> list;

	private static void method1() {
		LinkedList<Stack<Integer>> list = new LinkedList();

		for (int i = 0; i < M; i++) {
			Stack<Integer> stack = new Stack();
			for (int j = 0; j < N; j++) {
				stack.add(arry[j][i]);
			}
			list.add(stack);
		}
		for (int i = 0; i < M; i++) {
			Stack<Integer> stack = list.poll();
			for (int j = 0; j < N; j++) {
				arry[j][i] = stack.pop();
			}
		}

	}

	private static void method2() {
		LinkedList<Stack<Integer>> list = new LinkedList();

		for (int i = 0; i < N; i++) {
			Stack<Integer> stack = new Stack();
			for (int j = 0; j < M; j++) {
				stack.add(arry[i][j]);
			}
			list.add(stack);
		}
		for (int i = 0; i < N; i++) {
			Stack<Integer> stack = list.poll();
			for (int j = 0; j < M; j++) {
				arry[i][j] = stack.pop();
			}
		}
	}
	
	private static void method3() {
		LinkedList<Stack<Integer>> temp = new LinkedList<>();
		for(int i =0; i< M;i++) {
			temp.add(new Stack<Integer>());	
		}
		for(int i=0; i< M;i++) {
			for(int j = 0 ; j < N; j++) {
				temp.get(i).push(arry[j][i]);
			}
		}
		
		int tmp = N;
		N= M;
		M = tmp;
		arry = new int[N][M];
		
		for(int i =0 ; i < N; i++) {
			
			for(int j= 0; j<M;j++) {
			
				arry[i][j] = temp.get(i).pop();
			}
		}
	}
	private static void method4() {
		LinkedList<Stack<Integer>> temp = new LinkedList<>();
		for(int i = 0 ; i < N; i++) {
			temp.add(new Stack<Integer>());
		}
		for(int i = 0 ; i < N;i++) {
			for(int j = 0 ; j < M ; j++) {
				temp.get(i).push(arry[i][j]);
			}
		}
		int tmp = N;
		N= M;
		M = tmp;
		arry = new int[N][M];
		for(int i = 0 ; i < N; i++) {
			for(int j=0; j< M; j++) {
				arry[i][j] = temp.get(j).pop();
			}
		}
	}
	//array를 section으로 나눠주기
	private static void divideSection() {
		list = new LinkedList<>();
		for(int i=0; i < 4; i++) {
			//LinkedList<Integer> section = new LinkedList();
			list.add(new LinkedList<Integer>());
		}
		for(int i = 0 ; i < N ; i++) {
			for(int j = 0 ; j < M ; j ++) {
				//1 섹션
				if(i<N/2&&j<M/2) {
					list.get(0).add(arry[i][j]);
				}
				//2 섹션
				else if(i < N/2 && j >= M/2) {
					list.get(1).add(arry[i][j]);
				}
				//3섹션
				else if(i>=N/2&&j >= M/2) {
					list.get(2).add(arry[i][j]);
				}	
				//4섹션
				else if(i>=N/2&&j<M/2) {
					list.get(3).add(arry[i][j]);
				}
			}
		}
	}
	
	private static void method5() {
		list.addFirst(list.pollLast());
		sectionArray();
	}
	
	private static void method6() {
		list.addLast(list.poll());
		sectionArray();
	}
	//섹션으로 나뉘었던 것 돌려놓기
	private static void sectionArray() {
		for(int i = 0 ; i < N; i++) {
			for(int j = 0 ; j < M; j++) {
				//1 섹션
				if(i<N/2&&j<M/2) {
					arry[i][j] = list.get(0).poll();
				}
				//2 섹션
				else if(i < N/2 && j >= M/2) {
					arry[i][j] = list.get(1).poll();
				}
				//3섹션
				else if(i>=N/2&&j >= M/2) {
					arry[i][j] = list.get(2).poll();
				}	
				//4섹션
				else if(i>=N/2&&j<M/2) {
					arry[i][j] = list.get(3).poll();
				}
				
			}
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();
		
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());
		R = Integer.parseInt(st.nextToken());
		arry = new int[N][M];
		for (int i = 0; i < N; i++) {
			st = new StringTokenizer(br.readLine(), " ");

			for (int j = 0; j < M; j++) {

				arry[i][j] = Integer.parseInt(st.nextToken());

			}
			// System.out.println(Arrays.toString(arry[i]));
		}
		st = new StringTokenizer(br.readLine(), " ");
		for(int i = 0 ; i < R;i++) {
			switch(Integer.parseInt(st.nextToken())) {
			case 1:
				method1();
				break;
			case 2:
				method2();
				break;
			case 3:
				method3();
				break;
			case 4:
				method4();
				break;
			case 5:
				divideSection();
				method5();
				break;
			case 6:
				divideSection();
				method6();
				break;
			}
		}
		for(int i = 0 ; i< N;i++) {
			for(int j = 0 ; j < M ; j++) {
				sb.append(arry[i][j]+" ");
			}
			sb.append("\n");
		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}
}
