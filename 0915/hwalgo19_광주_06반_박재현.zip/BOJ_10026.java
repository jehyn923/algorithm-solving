package com.ssafy.algo.hw0825;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BOJ_10026 {
	static char[][] map;
	static int spaceForNorm;
	static int spaceForRG;
	static boolean[][] visited;
	static int N;
	static final int[][] directions = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine());
		StringBuilder sb = new StringBuilder();
		map = new char[N][];
		visited = new boolean[N][N];
		for (int i = 0; i < N; i++) {
			map[i] = br.readLine().toCharArray();

		}
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				dfs(j, i, 'n');

			}
		}
		visited = new boolean[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				dfsRG(j, i, 'n');

			}
		}
		System.out.println(spaceForNorm + " " + spaceForRG);
	}

	private static void dfsRG(int currentX, int currentY, char color) {
		if (visited[currentY][currentX]) {
			return;
		}
		if (color == 'n') {
			spaceForRG++;
			color = map[currentY][currentX];
		}
		visited[currentY][currentX] = true;
		for (int i = 0; i < 4; i++) {
			int newX = currentX + directions[i][1];
			int newY = currentY + directions[i][0];

			if (newX >= 0 && newX < N && newY >= 0 && newY < N && !visited[newY][newX]) {
				if (color == map[newY][newX] || (color == 'R' && map[newY][newX] == 'G')
						|| (color == 'G' && map[newY][newX] == 'R')) {
					dfsRG(newX, newY, color);
				}

			}
		}
	}

	private static void dfs(int currentX, int currentY, char color) {
		if (visited[currentY][currentX]) {
			return;
		}

		if (color == 'n') {
			spaceForNorm++;
			color = map[currentY][currentX];
		}
		visited[currentY][currentX] = true;
		for (int i = 0; i < 4; i++) {
			int newX = currentX + directions[i][1];
			int newY = currentY + directions[i][0];
			if (newX >= 0 && newX < N && newY >= 0 && newY < N && !visited[newY][newX] && color == map[newY][newX]) {
				dfs(newX, newY, color);
			}
		}
	}

}
