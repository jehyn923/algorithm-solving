package com.ssafy.algo.hw0824;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class SWEA_7465 {
	static boolean [][] adjMat;
	static boolean [] visited;
	
	static int groups;
	static int N;
	static int M;
	
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TC = Integer.parseInt(br.readLine());
		StringTokenizer st;
		StringBuilder sb = new StringBuilder();
		for (int tc = 0; tc < TC; tc++) {
			st = new StringTokenizer(br.readLine(), " ");
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			adjMat = new boolean [N+1][N+1];
			visited = new boolean [N+1];
			for(int i = 0 ;  i < M ; i ++ ){
				st = new StringTokenizer(br.readLine(), " ");
				int from = Integer.parseInt(st.nextToken());
				int to = Integer.parseInt(st.nextToken());
				
				adjMat[from][to] = adjMat[to][from] = true;
			}
			
			for(int i = 1 ; i <= N ; i++) {
				
				dfs(i, false);
			}
			sb.append("#"+(tc+1)+" "+groups+"\n");
			groups = 0;
		}
		System.out.println(sb.toString());
	}
	private static void dfs(int start, boolean newGroup) {
		if(visited[start]) {
			return;
		}
		else {
			if(!newGroup) groups++;
			newGroup = true;
			visited[start] = true;
			for(int i = 1; i<=N;i++) {
				if(!visited[i] && adjMat[start	][i]) {
					dfs(i,newGroup);
				}
			}
		}
		
	}
}
