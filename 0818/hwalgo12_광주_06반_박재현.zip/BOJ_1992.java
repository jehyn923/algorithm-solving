package com.ssafy.algo.hw0818;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BOJ_1992 {
	static char[][] map;
	static int[] N;

	private static String compression(int x, int y, int length) {
		StringBuilder sb = new StringBuilder();
		boolean compressable = true;
		char tmp = map[y][x];
		
		if (length == 0) {
			sb.append(tmp);
			return sb.toString();
		}
		
		loopOut:
		for (int i = 0; i < length; i++) {
			for (int j = 0; j < length; j++) {
				if (map[y + i][x + j] != tmp) {
					compressable = false;
					break loopOut;
				}
			}
		}
		//압축 불가하면 divide
		if(!compressable) {
			sb.append("(");
			// 1사분면
			sb.append(compression(x, y, length / 2));
			// 2사분면
			sb.append(compression(x + length / 2, y, length / 2));
			// 3사분면
			sb.append(compression(x, y + length / 2, length / 2));
			// 4사분면
			sb.append(compression(x + length / 2, y + length / 2, length / 2));	
			sb.append(")");
		
		}
		else {
			sb.append(tmp);
		}
		return sb.toString();
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int N = Integer.parseInt(br.readLine());
		StringBuilder sb = new StringBuilder();
		map = new char[N][];
		for (int i = 0; i < N; i++) {
			map[i] = br.readLine().toCharArray();
		}
		sb.append(compression(0,0,N));
		System.out.println(sb.toString());
	}
}
