use hwdb;

# emp와 dept Table을 JOIN하여 이름, 급여, 부서명을 검색하세요.
select e.ename, e.sal, d.DNAME 
from emp e left join dept d
using (DEPTNO);

# 이름이 'KING'인 사원의 부서명을 검색하세요.
select d.dname 
from emp e inner join dept d 
using (DEPTNO)
where e.ename = 'KING';

# dept table에 있는 모든 부서를 출력하고, emp Table에 있는 
# data와 join하여 모든 사원의 이름, 부서번호, 부서명, 급여를 출력하라
select d.DNAME, e.ENAME , e.DEPTNO , d.DNAME , e.SAL 
from dept d left join emp e 
using (DEPTNO);

# emp table에 있는 empno와 mgr을 이용하여 서로의 관계를 다음과 같이 출력되도록 
# 쿼리를 작성하세요. 'SCOTT의 매니저는 JONES이다.'


# 'SCOTT'의 직무와 같은 사람의 이름, 부서명, 급여, 직무를 검색하세요.
select e.ENAME, d.DNAME , e.SAL , e.JOB 
from EMP e left join DEPT d 
using(DEPTNO)
where job = 
(
select job from emp 
where ename = 'SCOTT'
);
# 'SCOTT'가 속해 있는 부서의 모든 사람의 사원번호, 이름,부서명, 
# 입사일, 지역, 급여를 검색하세요.
select e.EMPNO ,e.ENAME ,d.DNAME ,e.HIREDATE ,e.SAL 
from EMP e left join dept d
using (DEPTNO)
where e.DEPTNO = 
(
select deptno where ename = 'SCOTT'
);


# 전체 사원의 평균급여보다 급여가 많은 사원의 사원번호, 이름, 부서명,
# 입사일, 지역, 급여를 검색하세요.
select e.EMPNO , e.ENAME , d.DNAME , e.HIREDATE , d.loc , e.SAL 
from emp e left join dept d
using(DEPTNO)
where sal > (select avg(sal) from emp);

# 30번 부서와 같은 일을 하는 사원의 사원번호, 이름, 부서명, 지역, 급여를 급여가 
# 급여가 많은 순으로 검색하세요.

select e.EMPNO , e.ENAME ,e.JOB ,d.DNAME , d.LOC , e.SAL 
from emp e left join dept d 
using (DEPTNO)
where job in (
select e.job
from dept d left join emp e
using (DEPTNO)
where deptno = 30
group by e.job
);

# 10번 부서 중에서 30번 부서에는 없는 업무를 하는 사원의 사원번호, 이름, 부서명, 입사일, 
# 지역을 검색하세요.
select e.EMPNO , e.ENAME , d.DNAME , e.HIREDATE 
from emp e left join dept d
using (DEPTNO)
where e.deptno = 10 and e.job not in (
select e.job
from dept d left join emp e
using (DEPTNO)
where deptno = 30
group by e.job
);

# KING이나 JAMES의 급여와 같은 사원의 사원번호, 이름, 급여를 검색하세요.
# 이거 king james 말고 안나와야할
select EMPNO , ENAME , SAL 
from EMP
where sal in (select sal from emp where ename = 'KING' or ename = 'JAMES') 
and not (ename = 'KING' or ename='JAMES');

# 급여가 30번 부서의 최고 급여보다 높은 사원의 사원번호, 이름, 급여를 검색하세요.
select EMPNO , ENAME , SAL 
from emp
where sal > 
(select max(sal) from emp 
where DEPTNO = 30)


# 이름 검색을 보다 빠르게 수행하기 위해 emp 테이블 ename에 인덱스를 생성하시오.
create index ename_index on emp (ename);
show index from emp;

# 이름이 'ALLEN'인 사원의 입사연도가 같은 사원들의 이름과 급여를 출력하세요.
select ename,HIREDATE 
from EMP
where year(hiredate) = (select year(HIREDATE) from emp where ename='ALLEN');

# 부서별 급여의 합계를 출력하는 View를 작성하세요
create view v_sal_deptno as select d.DNAME , sum(e.sal) as "합계" from dept d left join emp e using(DEPTNO) group by DEPTNO;
select * from v_sal_deptno;
# 14번에서 작성된 View를 이용하여 부서별 급여의 합계가 큰 1~3순위를 출력하세요.
select * from v_sal_deptno
order by 합계 desc
limit 3;

