use hwdb;

#부서위치가 CHICAGO인 모든 사원에 대해 이름, 업무, 급여 출력하는 SQL 작
select ename, job, sal from emp inner join dept on emp.deptno = dept.deptno where loc="CHICAGO";

# 부하직원이 없는 사원의 사원번호, 이름, 업무, 부서번호 출력하는 SQL을 작
# empnno가 mgr 뭉치없는 친구들 select 
select empno, ename, job, deptno from emp 
where empno not in
(
# mgr들 갖고 오기
select mgr from emp where not mgr is NULL group by mgr
);

# BLAKE와 같은 상사를 가진 사원의 이름, 업무, 상사번호 출력하는 SQL 작
select ename, job, mgr from emp where mgr = 
(select mgr from emp where ename="BLAKE")

# 입사일이 가장 오래된 사람 5명 검색
select *
from emp
order by DATE(hiredate) ASC
limit 5;

# JONES의 부하 직원의 이름, 업무, 부서명을 검색세요.
select e.ename, e.job, e.hiredate, d.DNAME 
from emp e left outer join dept d
using (deptno)
where mgr = (select empno from emp where ename = "JONES");
