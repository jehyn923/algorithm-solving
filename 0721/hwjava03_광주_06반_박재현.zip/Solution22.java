package com.ssafy.algo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution22 {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = null;
		int N;
		int bugCount;
		int[][] bug;
		int[][] map;
		int T = Integer.parseInt(br.readLine());
		int[] survivor = new int[T];

		for (int tests = 0; tests < T; tests++) {
			st = new StringTokenizer(br.readLine(), " ");
			N = Integer.parseInt(st.nextToken());
			bugCount = Integer.parseInt(st.nextToken());
			map = new int[N][N];
			bug = new int[bugCount][3];

			// 소금쟁이 초기화
			for (int i = 0; i < bug.length; i++) {
				st = new StringTokenizer(br.readLine(), " ");

				for (int j = 0; j < 3; j++) {
					bug[i][j] = Integer.parseInt(st.nextToken());

				}
			}
			
			for (int i = 0; i < bug.length; i++) {
				int row = bug[i][0];
				int col = bug[i][1];

				if (map[row][col] != 1) {
					switch (bug[i][2]) {
					case 1:
						if (row - 6 >= 0) {
							if (map[row - 3][col] != 1 && map[row - 5][col] != 1 && map[row - 6][col] != 1) {
								map[row - 6][col] = 1;
								survivor[tests]++;
							}
						}
						break;
					case 2:
						if (row + 6 <= map.length - 1) {
							if (map[row + 3][col] != 1 && map[row + 5][col] != 1 && map[row + 6][col] != 1) {
								map[row + 6][col] = 1;
								survivor[tests]++;
							}
						}
						break;
					case 3:
						if (col - 6 >= 0) {
							if (map[row][col - 3] != 1 && map[row][col - 5] != 1 && map[row][col - 6] != 1) {
								map[row][col - 6] = 1;
								survivor[tests]++;
							}
						}
						break;
					case 4:
						if (col + 6 <= map.length - 1) {
							if (map[row][col + 3] != 1 && map[row][col + 5] != 1 && map[row][col + 6] != 1) {
								map[row][col + 6] = 1;
								survivor[tests]++;
							}
						}
						break;
					}
				}
			}

		}
		for(int i = 0 ; i < T; i++) {
			System.out.println("#" +(i +1) +" "+survivor[i]);
		}
	}
}
