package com.ssafy.algo.hw0810;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BOJ_2563 {
	static int[][] canvas = new int[100][100];
	
	private static void draw(int startX, int startY) {
		for(int y=startY;y<startY+10;y++) {
			
			for(int x=startX;x<startX+10;x++) {
				if(canvas[y][x]==1) {
					continue;
				}
				canvas[y][x]=1;
			}
		}
	}
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TC = Integer.parseInt(br.readLine());
		StringTokenizer st;
		StringBuilder sb = new StringBuilder();
		for (int tc = 0; tc < TC; tc++) {
			st = new StringTokenizer(br.readLine(), " ");
			draw(Integer.parseInt(st.nextToken())-1,Integer.parseInt(st.nextToken())-1);
		}
		int cnt = 0; 
		for(int i = 0 ; i < canvas.length;i++) {
			for(int j = 0 ; j < canvas[i].length;j++) {
				if(canvas[i][j] == 1) cnt+=1;
			}
			System.out.println(Arrays.toString(canvas[i]));
		}
		System.out.println(cnt);
	
	}
}
