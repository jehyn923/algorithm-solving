package com.ssafy.algo.hw0805;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BOJ_2493_TOP {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int numbers = Integer.parseInt(br.readLine());
		int[] towerHeights = new int[numbers];
		int[] result = new int[numbers];
	
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		StringBuilder sb = new StringBuilder();
		
		//initialization
		for(int i=0;i<numbers; i ++) {
			int height= Integer.parseInt(st.nextToken()) ;
			towerHeights[i] = height;
		}
		result[0]=0;
		for(int i=1;i<numbers;i++) {
			if(towerHeights[i]<towerHeights[i-1]) {
				//+1 해서 저장
				result[i] = i;
				continue;
			}
			//저장한 값이 +1 되어있으니 -1 해서 조회
			int loc = result[i-1]-1;
			while(true) {
				if(loc<0) {
					result[i] = 0;
					break;
				} else if(towerHeights[i]<towerHeights[loc]) {
					result[i] = loc+1;
					break;
				} else {
					loc = result[loc]-1;
				}
			
			}
		}
		for(int i = 0 ; i < numbers;i++) {
			sb.append(result[i]+ " ");
			
		}
		System.out.println(sb);
	}

}
