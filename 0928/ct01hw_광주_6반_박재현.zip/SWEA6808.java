package com.ssafy.algo.w0812;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class SWEA6808 {
	static int[] kyu=new int[9];
	static int[] me=new int[9];
	//lose count, win count
	static int[] result=new int[2];
	
	private static void permutation(int toSelect, int[] selected, boolean[] visited) {
		if(toSelect == 9) {
			int kyuScore = 0;
			int meScore = 0;
			
			for(int i = 0 ;i < selected.length; i++){
				if(kyu[i]>selected[i]) {
					kyuScore=kyuScore+kyu[i]+selected[i];
				}else {
					meScore=meScore+kyu[i]+selected[i];
				}
			}
			
			if(kyuScore>meScore) {
				result[1]++;
			}
			
			else if(kyuScore<meScore){
				result[0]++;
			}
			return;
		}
		
		for(int i = 0; i < me.length ;i++) {
			if(!visited[i]){
				visited[i] = true;
				selected[toSelect] = me[i];
				permutation(toSelect+1, selected, visited);
				visited[i] = false;
			}
		}
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		int TC = Integer.parseInt(br.readLine());
		StringTokenizer st;
		StringBuilder sb = new StringBuilder();
		for (int tc = 0; tc < TC; tc++) {
			boolean[] kyuCard=new boolean[18] ;
			result[0]=0;
			result[1]=0;
			st = new StringTokenizer(br.readLine(), " ");
			for(int i = 0 ; i < 9 ; i ++) {
				kyu[i] = Integer.parseInt(st.nextToken());
				kyuCard[kyu[i]-1] = true;
			}
			int j = 0 ;
			for(int i = 1; i <=18 ; i++) {
				if(kyuCard[i-1]) {
					continue;
				}
				me[j++] = i;
			}
			permutation(0,new int[me.length], new boolean[me.length]);
			sb.append("#"+ (tc+1)+" "+result[1]+" "+result[0]+"\n");
			
		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}
}
