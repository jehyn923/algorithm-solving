package com.ssafy.algo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class DigitTest1 {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = null;
		
		int[] frequency = new int[10];
		int num; 
		
		st = new StringTokenizer(br.readLine()," ");
		
		do {
			num = Integer.parseInt(st.nextToken());
			if(num != 0) {
				frequency[num/10]+= 1;
			}
		}while(num!=0);
		

		for(int i = 0 ; i < frequency.length; i++) {
			if(frequency[i]>0) {
				System.out.println(i+ " : "+frequency[i]+"개");
			}
		}
	}
}
