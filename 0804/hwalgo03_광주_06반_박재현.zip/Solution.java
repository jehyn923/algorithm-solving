package com.ssafy.algo.hw0804;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int TC = Integer.parseInt(br.readLine());
		int[][] map;
		int[][] flyCount;
		int N;
		int M;
		StringTokenizer st;
		StringBuilder sb = new StringBuilder();
		for (int tc = 0; tc < TC; tc++) {
			st = new StringTokenizer(br.readLine(), " ");
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			// 전체 맵
			map = new int[N][N];
			// 맵에서 파리채가 커버할 수 있는 파리 갯수
			flyCount = new int[N][N - M + 1];

			for (int i = 0; i < N; i++) {
				st = new StringTokenizer(br.readLine(), " ");
				for (int j = 0; j < N; j++) {
					map[i][j] = Integer.parseInt(st.nextToken());
				}

				for (int j = 0; j < flyCount[i].length; j++) {
					for (int k = j; k < j + M; k++) {
						flyCount[i][j] += map[i][k];
					}

				}
			}
			int max = 0;
			int sum;
			for (int i = 0; i < flyCount[i].length; i++) {
				for (int j = 0; j < N - M + 1; j++) {
					sum = 0;
					for (int k = j; k < j + M; k++) {
						sum += flyCount[k][i];
					}
					if (sum > max) {
						max = sum;
					}
				}
			}
			sb.append("#" + (tc + 1) + " " + max + "\n");
		}
		System.out.println(sb);
	}
}
